/**
 * @file Chicken.h
 *
 * @author Ricky Pennepalli
 *
 * Declaration of the Chicken class.
 */

#ifndef STEP1_CHICKEN_H
#define STEP1_CHICKEN_H
#include "Animal.h"
#include <string>

/**
* Class that describes a chicken.
*/
class Chicken : public Animal
{
    public:
        void ObtainChickenInformation(); /// Get chicken information from user
        void DisplayAnimal(); /// Display chicken information

    private:
        /// The chicken's ID
        std::string mId;
};


#endif //STEP1_CHICKEN_H