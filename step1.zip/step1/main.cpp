 /**
 * @file main.cpp
 * Main entry point.
 *
 * @author Ricky Pennepalli
 *
 */

#include <iostream>
#include "Farm.h"
#include "Cow.h"
#include "Chicken.h"
#include "Goat.h"
using namespace std;

/**
 * Main Function
 *
 * Creates Farm Object and performs appropriate tasks.
 * This is where the program starts.
 * @return 0
 */
int main()
{
    cout << "Instantiating Farm" << endl;
    Farm farm;
    // This loops continuously until we are done
    bool done = false;
    while (!done)
    {
        // Output user instructions
        cout << endl;
        cout << "Farm management" << endl;
        cout << "1 - Add Cow" << endl;
        cout << "2 - Add Chicken" << endl;
        cout << "3 - Add Goat" << endl;
        cout << "8 - Number of female animals" << endl;
        cout << "9 - List inventory" << endl;
        cout << "99 - Exit" << endl;
        cout << "Select Option: ";

        // Get option from the user
        int option;
        cin >> option;

        // Handle invalid  input
        if (!cin)
        {
            option = 1000;
            cin.clear();
            cin.ignore();  // Discard bad input
        }

        // Handle the possible user options
        switch (option)
        {
            // Create cow object for the farm
            case 1:
                {
                    cout << "Adding cow" << endl;
                    Cow *cow = new Cow();
                    cow->ObtainCowInformation();
                    if (cow->isFemale())
                    {
                        farm.AddFemale();
                    }
                    farm.AddAnimal(cow);
                }
                break;

            // Create chicken object for the farm
            case 2:
                {
                    cout << "Adding chicken" << endl;
                    Chicken *chicken = new Chicken();
                    chicken->ObtainChickenInformation();
                    farm.AddAnimal(chicken);
                    farm.AddFemale();
                }
                break;

            // Create goat object for the farm
            case 3:
            {
                cout << "Adding goat" << endl;
                Goat *goat = new Goat();
                goat->ObtainGoatInformation();
                if (goat->isFemale())
                {
                    farm.AddFemale();
                }
                farm.AddAnimal(goat);
            }
                break;

            // Display all female animals using function in farm
            case 8:
                farm.DisplayFemale();
                break;

            // Display inventory using function in farm
            case 9:
                farm.DisplayInventory();
                break;

            // End loop
            case 99:
                done = true;
                break;

            // Catch invalid options
            default:
                cout << "Invalid option" << endl;
                break;
        }
    }

    return 0;
}