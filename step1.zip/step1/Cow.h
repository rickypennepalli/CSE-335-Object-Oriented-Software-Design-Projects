/**
 * @file Cow.h
 *
 * @author Ricky Pennepalli
 *
 * Declaration of the Cow class.
 */
#ifndef STEP_1_COW_H
#define STEP_1_COW_H
#include "Animal.h"
#include <string>

/**
* Class that describes a cow.
*/
class Cow : public Animal
{
    public:
        /// Types of cows
        enum class Type {Bull, BeefCow, MilkCow};
        void ObtainCowInformation(); /// Get cow information from user
        void DisplayAnimal(); /// Display cow information
        bool isFemale(); /// check if cow is female

    private:
        /// The cow's name
        std::string mName;
        /// The type of cow: Bull, BeefCow, or MilkCow
        Type mType =Type::MilkCow;
        /// The milk production for a cow in gallons per day
        double mMilkProduction = 0;
};


#endif //STEP_1_COW_H
