/**
 * @file Animal.cpp
 *
 * @author Ricky Pennepalli
 *
 */
#include "Animal.h"

/**
 * Destructor
 */
Animal::~Animal()
{
}
