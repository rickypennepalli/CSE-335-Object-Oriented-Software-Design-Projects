/**
 * @file Farm.h
 *
 * @author your_name_here
 *
 * Declaration of the Farm class.
 */

#ifndef STEP1_FARM_H
#define STEP1_FARM_H
#include <vector>
#include "Cow.h"

/**
 * Class that describes a farm.
 *
 * Holds a collection of animals that make up the farm
 * inventory.
 */
class Farm
{
    public:
        void AddAnimal(Animal *animal); /// Adds animal to inventory
        void DisplayInventory(); /// Displays inventory
        void AddFemale(); /// Increments count of female animals
        void DisplayFemale(); /// Displays count of female animals
        ~Farm(); /// Farm destructor

    private:
        /// A list with the inventory of all animals on the farm
        std::vector<Animal *> mInventory;
        /// count of female animals on the farm
        int mFemale = 0;
};


#endif //STEP1_FARM_H