/**
 * @file Goat.h
 *
 * @author Ricky Pennepalli
 *
 * Declaration of the Goat class.
 */

#ifndef STEP_1_GOAT_H
#define STEP_1_GOAT_H
#include "Animal.h"
#include "string"

/**
* Class that describes a goat.
*/
class Goat : public Animal
{
    public:
        /// Types of goats
        enum class Type {Nanny, Billy, Wether, Male_Kid, Female_Kid};
        void ObtainGoatInformation(); /// Get goat information from user
        void DisplayAnimal(); /// Display goat information
        bool isFemale(); /// check if goat is female

    private:
        /// The goat's name
        std::string mName;
        /// The type of goat: Nanny, Billy, Wether, Make Kid, Female Kid
        Type mType =Type::Nanny;
};

#endif //STEP_1_GOAT_H
