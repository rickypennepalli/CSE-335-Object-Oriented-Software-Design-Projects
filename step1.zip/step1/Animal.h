/**
 * @file Animal.h
 *
 * @author Ricky Pennepalli
 *
 * Declaration of the Animal class.
 */

#ifndef STEP_1_ANIMAL_H
#define STEP_1_ANIMAL_H

/**
* Base class for all animals.
*/
class Animal
{
    public:
        virtual ~Animal(); /// Animal destructor
        /** Display an animal. */
        virtual void DisplayAnimal() {}

};

#endif //STEP_1_ANIMAL_H
