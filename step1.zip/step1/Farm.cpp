/**
 * @file Farm.cpp
 *
 * @author Ricky Pennepalli
 *
 */
#include <iostream>
#include "Farm.h"
#include "Animal.h"
using namespace std;

/** Add an animal to the farm inventory.
*
* @param animal to add to the inventory
*/
void Farm::AddAnimal(Animal *animal)
{
    mInventory.push_back(animal);
}

/**
 * Display the farm inventory.
 */
void Farm::DisplayInventory()
{
    for (auto animal : mInventory)
    {
        animal->DisplayAnimal();
    }
}

/**
 * Increment the count of female animals
 */
void Farm::AddFemale()
{
    mFemale += 1;
}

/**
 * Display the count of female animals
 */
void Farm::DisplayFemale()
{
    cout << "There are " << mFemale << " female animals" << endl;
}

/**
 * Farm destructor
 */
Farm::~Farm()
{
    // Iterate over all of the animals, destroying
    // each one.
    for (auto animal : mInventory)
    {
        delete animal;
    }

    // And clear the list
    mInventory.clear();
}