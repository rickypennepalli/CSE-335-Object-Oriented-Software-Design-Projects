/**
 * @file main.cpp
 * @author Charles B. Owen
 *
 * Main entry point for program
 */
#include "pch.h"
#include "CanadianExperienceApp.h"

wxIMPLEMENT_APP(CanadianExperienceApp);

