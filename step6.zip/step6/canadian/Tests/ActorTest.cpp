#include <pch.h>
#include "gtest/gtest.h"
#include "Actor.h"


TEST(ActorTest, Constructor)
{
    Actor actor(L"Harold");
    ASSERT_EQ(std::wstring(L"Harold"), actor.GetName());
}

TEST(ActorTest, Enabled)
{
    Actor actor(L"Harold");

    ASSERT_TRUE(actor.IsEnabled());
    actor.SetEnabled(FALSE);
    ASSERT_FALSE(actor.IsEnabled());
}

TEST(ActorTest, Clickable)
{
    Actor actor(L"Harold");

    ASSERT_TRUE(actor.IsClickable());
    actor.SetClickable(FALSE);
    ASSERT_FALSE(actor.IsClickable());
}

TEST(ActorTest, Position)
{
    Actor actor(L"Harold");

    ASSERT_EQ(actor.GetPosition(),  wxPoint(0,0));
    actor.SetPosition(wxPoint(50,50));
    ASSERT_EQ(actor.GetPosition(),  wxPoint(50,50));
}