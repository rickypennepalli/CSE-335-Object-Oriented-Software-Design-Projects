/**
 * @file pch.h
 * @author your_name_here
 */

#ifndef CANADIANEXPERIENCE_PCH_H
#define CANADIANEXPERIENCE_PCH_H

#include <wx/wxprec.h>
#ifndef WX_PRECOMP
#include <wx/wx.h>
#endif

#endif //CANADIANEXPERIENCE_PCH_H
