/**
 * @file Drawable.h
 * @author Ricky Pennepalli
 *
 * Abstract base class for drawable elements of our picture.
 *
 */


#ifndef CANADIANEXPERIENCE_DRAWABLE_H
#define CANADIANEXPERIENCE_DRAWABLE_H
#include <memory>

class Actor;

/**
 * Abstract base class for drawable elements of our picture.
 *
 * A drawable is one part of an actor. Drawable parts can be moved
 * independently.
 */
class Drawable {
private:
    /// The name drawable
    std::wstring mName;
    /// The rotation double
    double mRotation = 0;

    /// The actor using this drawable
    Actor *mActor = nullptr;

    /// The children drawables
    std::vector<std::shared_ptr<Drawable>> mChildren;
    /// drawable parent
    Drawable *mParent = nullptr;


protected:
    Drawable(const std::wstring &name);

    /// point for placed position
    wxPoint mPlacedPosition;
    /// double for placedR
    double mPlacedR = 0;
    /// point for rotate point
    wxPoint RotatePoint(wxPoint point, double angle);
    /// point for position
    wxPoint mPosition;

public:
    virtual ~Drawable();
    /// Copy Constructor (Disabled)
    Drawable(const Drawable &) = delete;
    /// Assignment Operator (Disabled)
    void operator=(const Drawable &) = delete;

    void SetActor(Actor* actor);
    void Place(wxPoint offset, double rotate);
    void AddChild(std::shared_ptr<Drawable> child);
    void SetParent(Drawable *parent);
    void Move(wxPoint delta);

    /**
     * Draw this drawable
     * @param graphics Graphics object to draw on
     */
    virtual void Draw(std::shared_ptr<wxGraphicsContext> graphics) = 0;

    /**
     * Test to see if we have been clicked on by the mouse
     * @param pos Position to test
     * @return true if clicked on
     */
    virtual bool HitTest(wxPoint pos) = 0;

    /**
     * Is this a movable drawable?
     * @return true if movable
     */
    virtual bool IsMovable() { return false; }

    /**
     * Set the drawable position
     * @param pos The new drawable position
     */
    void SetPosition(wxPoint pos) { mPosition = pos; }

    /**
     * Get the drawable position
     * @return The drawable position
     */
    wxPoint GetPosition() const { return mPosition; }

    /**
     * Set the rotation angle in radians
    * @param r The new rotation angle in radians
     */
    void SetRotation(double r) { mRotation = r; }

    /**
     * Get the rotation angle in radians
     * @return The rotation angle in radians
     */
    double GetRotation() const { return mRotation; }

    /**
     * Get the drawable name
     * @return The drawable name
     */
    std::wstring GetName() const { return mName; }

    /**
     * Get the drawable parent
     * @return mParent The drawable parent
     */
    Drawable* GetParent() const { return mParent; }

};


#endif //CANADIANEXPERIENCE_DRAWABLE_H
