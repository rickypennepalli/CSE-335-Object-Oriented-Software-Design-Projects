/**
 * @file SecondFactory.h
 * @author Ricky Pennepalli
 *
 * Factory class that builds the Second character
 */

#ifndef CANADIANEXPERIENCE_SECONDFACTORY_H
#define CANADIANEXPERIENCE_SECONDFACTORY_H

class Actor;

/**
 * Factory class that builds the Second character
 */
class SecondFactory {
public:
    std::shared_ptr<Actor> Create(std::wstring imagesDir);
};


#endif //CANADIANEXPERIENCE_SECONDFACTORY_H
