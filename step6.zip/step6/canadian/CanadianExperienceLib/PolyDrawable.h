/**
 * @file PolyDrawable.h
 * @author Ricky Pennepalli
 *
 * A drawable based on polygon images.
 *
 */

#ifndef CANADIANEXPERIENCE_POLYDRAWABLE_H
#define CANADIANEXPERIENCE_POLYDRAWABLE_H
#include "Drawable.h"


/**
 * This class has a list of points and draws a polygon
 * drawable based on those points.
 */
class PolyDrawable : public Drawable {
private:
    /// The polygon color
    wxColour mColor = *wxBLACK;
    /// The array of point objects
    std::vector<wxPoint> mPoints;
    /// path for wxGraphics path
    wxGraphicsPath mPath;

public:
    virtual ~PolyDrawable() {}
    PolyDrawable(const std::wstring &name);

    /// Default constructor (disabled)
    PolyDrawable() = delete;
    /// Copy constructor (disabled)
    PolyDrawable(const PolyDrawable &) = delete;
    /// Assignment operator
    void operator=(const PolyDrawable &) = delete;

    /**
     * Draw this drawable
     * @param graphics Graphics object to draw on
     */
    virtual void Draw(std::shared_ptr<wxGraphicsContext> graphics) override;

    /**
     * Test to see if we have been clicked on by the mouse
     * @param pos Position to test
     * @return true if clicked on
     */
    virtual bool HitTest(wxPoint pos) override;

    /**
     * Add point
     * @param point Point to Add
     */
    void AddPoint(wxPoint point);

    /**
     * Set the color
     * @param colour The new colour
     */
    void SetColor(wxColour colour) { mColor = colour; }

    /**
     * Get the new color
     * @return The color
     */
    wxColour GetColor() const { return mColor; }

};


#endif //CANADIANEXPERIENCE_POLYDRAWABLE_H
