/**
 * @file ImageDrawable.h
 * @author Ricky Pennepalli
 *
 * A drawable based on images.
 *
 */

#ifndef CANADIANEXPERIENCE_IMAGEDRAWABLE_H
#define CANADIANEXPERIENCE_IMAGEDRAWABLE_H
#include "Drawable.h"

/**
 * This class draws an image
 * drawable based on those points.
 */
class ImageDrawable : public Drawable {
protected:
    /// The image we are drawing
    std::unique_ptr<wxImage> mImage;
    /// The graphics bitmap we will use
    wxGraphicsBitmap mBitmap;
    /// The point for the center
    wxPoint mCenter;

public:
    virtual ~ImageDrawable() {}
    ImageDrawable(const std::wstring &name, const std::wstring &filename);

    /// Default constructor (disabled)
    ImageDrawable() = delete;
    /// Copy constructor (disabled)
    ImageDrawable(const ImageDrawable &) = delete;
    /// Assignment operator
    void operator=(const ImageDrawable &) = delete;

    void Draw(std::shared_ptr<wxGraphicsContext> graphics);

    bool HitTest(wxPoint pos);

    /**
     * Set the drawable center
     * @param pos The new drawable center
     */
    void SetCenter(wxPoint pos) { mCenter = pos; };

    /**
     * Get the center
     * @return center
     */
    wxPoint GetCenter() const { return mCenter; };

};


#endif //CANADIANEXPERIENCE_IMAGEDRAWABLE_H
