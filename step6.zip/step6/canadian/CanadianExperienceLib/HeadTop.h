/**
 * @file HeadTop.h
 * @author Ricky Pennepalli
 *
 * A drawable for the top of the head
 *
 */

#ifndef CANADIANEXPERIENCE_HEADTOP_H
#define CANADIANEXPERIENCE_HEADTOP_H
#include "ImageDrawable.h"

/**
 * A drawable class for the top of the head
 */
class HeadTop : public ImageDrawable {
private:
    /// left eye bitmap
    wxBitmap mLeftEye;
    /// right eye bitmap
    wxBitmap mRightEye;
    /// center of the eye point
    wxPoint mEyesCenter = wxPoint(55, 75);

public:
    virtual ~HeadTop() {}
    HeadTop(const std::wstring &name, const std::wstring &filename);

    /// Default constructor (disabled)
    HeadTop() = delete;
    /// Copy constructor (disabled)
    HeadTop(const HeadTop &) = delete;
    /// Assignment operator
    void operator=(const HeadTop &) = delete;

    void Draw(std::shared_ptr<wxGraphicsContext> graphics) override;

    wxPoint TransformPoint(wxPoint p);
    bool IsMovable() override;

    void DrawEye(std::shared_ptr<wxGraphicsContext> graphics, wxPoint point);
    void DrawEyebrow(std::shared_ptr<wxGraphicsContext> graphics, wxPoint left, wxPoint right);

    /**
     * Get the left eye bitmap
     * @return The left eye bitmap
     */
    wxBitmap *GetLeftEye() { return &mLeftEye; }

    /**
     * Get the right eye bitmap
     * @return The right eye bitmap
     */
    wxBitmap *GetRightEye() { return &mRightEye; }

};


#endif //CANADIANEXPERIENCE_HEADTOP_H
