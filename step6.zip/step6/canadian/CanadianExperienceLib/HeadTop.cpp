/**
 * @file HeadTop.cpp
 * @author Ricky Pennepalli
 *
 */

#include "HeadTop.h"
#include "ImageDrawable.h"

/**
 * Constructor
 * @param name The drawable name
 * @param filename The filename for the image
 */
HeadTop::HeadTop(const std::wstring &name, const std::wstring &filename) : ImageDrawable(name, filename) {

}

/** Transform a point from a location on the bitmap to
*  a location on the screen.
* @param  p Point to transform
* @returns Transformed point
*/
wxPoint HeadTop::TransformPoint(wxPoint p)
{
    // Make p relative to the image center
    p = p - GetCenter();

    // Rotate as needed and offset
    return RotatePoint(p, mPlacedR) + mPlacedPosition;
}

/**
 * Draw the image drawable
 * @param graphics Graphics context to draw on
 */
void HeadTop::Draw(std::shared_ptr<wxGraphicsContext> graphics) {
    ImageDrawable::Draw(graphics);

    int righteyeX = mEyesCenter.x + 12;
    int lefteyeX = mEyesCenter.x - 12;
    int botheyesY = mEyesCenter.y;

    DrawEye(graphics, wxPoint (lefteyeX, botheyesY));
    DrawEye(graphics, wxPoint (righteyeX, botheyesY));
    DrawEyebrow(graphics, wxPoint(righteyeX - 10, botheyesY - 16), wxPoint (righteyeX + 5, botheyesY - 18));
    DrawEyebrow(graphics, wxPoint(lefteyeX - 5, botheyesY - 19), wxPoint (lefteyeX + 10, botheyesY - 18));
}

/**
 * Draw the image drawable
 * @param graphics Graphics context to draw on
 * @param point wxPoint to transform
 */
void HeadTop::DrawEye(std::shared_ptr<wxGraphicsContext> graphics, wxPoint point)
{
    graphics->SetBrush(wxBrush(*wxBLACK));

    wxPoint p1 = TransformPoint(point);

    float wid = 15.0f;
    float hit = 20.0f;

    graphics->PushState();
    graphics->Translate(p1.x, p1.y);
    graphics->Rotate(-mPlacedR);
    graphics->DrawEllipse(-wid/2, -hit/2, wid, hit);
    graphics->PopState();

}

/**
 * Draw the image drawable
 * @param graphics wxGraphics
 * @param left left point
 * @param right right point
 */
void HeadTop::DrawEyebrow(std::shared_ptr<wxGraphicsContext> graphics, wxPoint left, wxPoint right)
{
    wxPoint leftEyebrow = TransformPoint(left);
    wxPoint rightEyebrow = TransformPoint(right);

    wxPen eyebrowsPen(*wxBLACK, 3);
    graphics->SetPen(eyebrowsPen);
    graphics->StrokeLine(leftEyebrow.x, leftEyebrow.y, rightEyebrow.x, rightEyebrow.y);
}

/**
 * Set is movable to true
 * @return bool true for movable
 */
bool HeadTop::IsMovable() {
    return true;
}
