/**
 * @file Actor.h
 * @author Ricky Pennepalli
 *
 * Class for actors in our drawings.
 */

#ifndef CANADIANEXPERIENCE_ACTOR_H
#define CANADIANEXPERIENCE_ACTOR_H
#include <memory>

class Drawable;
class Picture;

/**
 * Class for actors in our drawings.
 *
 * An actor is some graphical object that consists of
 * one or more parts. Actors can be animated.
 */
class Actor {
private:
    /// The name of actor
    std::wstring mName;
    /// The enabled status
    bool mEnabled = true;
    /// The position drawable
    wxPoint mPosition;
    /// The clickable status
    bool mClickable = true;

    /// The pointer to drawable
    std::shared_ptr<Drawable> mRoot;
    /// The drawables in drawing order
    std::vector<std::shared_ptr<Drawable>> mDrawablesInOrder;

    /// The actor using this drawable
    Picture *mPicture = nullptr;

public:
    virtual ~Actor() {}
    Actor(const std::wstring &name);

    /// Default constructor (disabled)
    Actor() = delete;
    /// Copy constructor (disabled)
    Actor(const Actor &) = delete;
    /// Assignment operator
    void operator=(const Actor &) = delete;

    void SetRoot(std::shared_ptr<Drawable> root);
    void Draw(std::shared_ptr<wxGraphicsContext> graphics);
    std::shared_ptr<Drawable> HitTest(wxPoint pos);
    void AddDrawable(std::shared_ptr<Drawable> drawable);

    void SetPicture(Picture* picture);

    /**
     * Get the actor name
     * @return Actor name
     */
    std::wstring GetName() const { return mName; }

    /**
     * The actor position
     * @return The actor position as a point
     */
    wxPoint GetPosition() const { return mPosition; }

    /**
     * The actor position
     * @param pos The new actor position
     */
    void SetPosition(wxPoint pos) { mPosition = pos; }


    /**
     * Actor is enabled
     * @return enabled status
     */
    bool IsEnabled() const { return mEnabled; }

    /**
     * Set Actor Enabled
     * @param enabled New enabled status
     */
    void SetEnabled(bool enabled) { mEnabled = enabled; }

    /**
     * Actor is clickable
     * @return true if actor is clickable
     */
    bool IsClickable() const { return mClickable; }

    /**
     * Actor clickable
     * @param clickable New clickable status
     */
    void SetClickable(bool clickable) { mClickable = clickable; }

    /**
     * Get the actor picture
     * @return Actor picture
     */
    Picture* GetPicture() const { return mPicture; };

};

#endif //CANADIANEXPERIENCE_ACTOR_H